# DiabeTech MVP

Web app básica para registro y visualización de datos de diabetes usando Flask.